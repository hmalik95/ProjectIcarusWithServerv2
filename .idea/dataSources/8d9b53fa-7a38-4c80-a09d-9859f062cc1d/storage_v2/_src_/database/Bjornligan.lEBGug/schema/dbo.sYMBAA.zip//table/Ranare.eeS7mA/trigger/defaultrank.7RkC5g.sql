Create trigger defaultrank
on rånare
after insert

as
	declare @defaultrank int = 0;

	update rånare set Rankning = @defaultrank where
	rånarID = (select rånarid from inserted)


	print 'fixat ranken';
GO

