create trigger råninfo_insert 
on rån 
after insert 
as 

declare @byte int = (select byte from inserted)
declare @bank nvarchar(50) = (select Bank.Namn from Bank join Rån_Bank on Bank.BankID=Rån_Bank.BankID where RånID in (select RånID from inserted))
declare @senasteRånID int = (select rånID from inserted)

insert into Rån_Bank(RånID,BankID)
values(@senasteRånID,4)

print 'tjensi penis ' + @bank + 'har förlorat: ' + cast(@byte as varchar)
GO

