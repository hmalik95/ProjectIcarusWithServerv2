CREATE VIEW tidigareRånAllInfo as
select rån.rånid, rån.byte, rån.offer, rån.datum, rån.flyktbil, bank.namn, flyktbil.färg 
from rån join Rån_Bank on rån.RånID=Rån_Bank.RånID join Bank on Bank.BankID = Rån_Bank.BankID join flyktbil on flyktbil.FlyktbilID=rån.Flyktbil;
GO

